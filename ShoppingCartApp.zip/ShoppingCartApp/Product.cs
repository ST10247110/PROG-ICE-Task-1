﻿public class Product
{
    private string name;
    private double price;
    private ProductCategory category;

    public string Name => name;
    public double Price => price;
    public ProductCategory Category => category;

    public Product(string name, double price, ProductCategory category)
    {
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public virtual void GetInfo()
    {
        Console.WriteLine("Name: " + name + ", Price: " + price + ", Category: " + category);
    }
}