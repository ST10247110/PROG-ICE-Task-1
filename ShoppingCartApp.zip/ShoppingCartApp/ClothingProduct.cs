﻿public class ClothingProduct : Product
{
    private string size;
    private string colour;

    public string Size => size;
    public string Colour => colour;

    public ClothingProduct(string name, double price, ProductCategory category, string size, string colour)
        : base(name, price, category)
    {
        this.size = size;
        this.colour = colour;
    }

    public override void GetInfo()
    {
        base.GetInfo();
        Console.WriteLine("Size: " + size + ", Color: " + colour);
    }
}