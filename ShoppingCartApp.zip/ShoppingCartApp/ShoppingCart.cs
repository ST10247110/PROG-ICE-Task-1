﻿public class ShoppingCart
{
    private Product[] products;
    private int itemCount;

    public Product[] Products => products;
    public int ItemCount => itemCount;

    public ShoppingCart(int capacity)
    {
        products = new Product[capacity];
        itemCount = 0;
    }

    public void AddProduct(Product product)
    {
        if (itemCount < products.Length)
        {
            products[itemCount] = product;
            itemCount++;
        }
        else
        {
            Console.WriteLine("Your shopping cart is full!");
        }
    }

    public void RemoveProduct(Product product)
    {
        for (int i = 0; i < itemCount; i++)
        {
            if (products[i] == product)
            {
                Array.Copy(products, i + 1, products, i, itemCount - i - 1);
                itemCount--;
                break;
            }
        }
    }
}