﻿class Program
{
    static void Main(string[] args) //Test Values for the App
    {
        var cart = new ShoppingCart(5);
        var clothingProduct = new ClothingProduct("Shirt", 20.99, ProductCategory.Clothing, "M", "Blue");
        var electronicsProduct = new ElectronicsProduct("Phone", 399.99, ProductCategory.Electronics, "Apple", "iPhone 13");

        cart.AddProduct(clothingProduct);
        cart.AddProduct(electronicsProduct);

        foreach (var product in cart.Products)
        {
            if (product != null)
            {
                product.GetInfo();
            }
        }
    }
}