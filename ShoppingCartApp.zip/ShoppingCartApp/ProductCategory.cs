﻿public enum ProductCategory
{
    Clothing,
    Electronics,
    Home,
    Beauty,
    Groceries
}